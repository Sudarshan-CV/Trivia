package com.sudarshancv.trivia.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.sudarshancv.trivia.R;

public class SecondGame2 extends AppCompatActivity {

    CheckBox White,Yellow,Orange,Green,all;
    Button button;
    StringBuffer stringBuffer = new StringBuffer();
    boolean flag=false;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_game2);
        sharedPreferences = getSharedPreferences("trivia",0);
        //Getting instance of CheckBoxes and Button from the activty_main.xml file
        White=(CheckBox)findViewById(R.id.checkBox1);
        Yellow=(CheckBox)findViewById(R.id.checkBox2);
        Orange=(CheckBox)findViewById(R.id.checkBox3);
        Green=(CheckBox)findViewById(R.id.checkBox4);
        all=(CheckBox)findViewById(R.id.checkBox5);
        button =(Button) findViewById(R.id.nextSecondGame);

        // by selecting all make all checkbox as true
        all.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

             @Override
             public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                 if(all.isChecked()){
                     White.setChecked(true);
                     Yellow.setChecked(true);
                     Orange.setChecked(true);
                     Green.setChecked(true);
                     flag=true;
                 }
           }
        }
        );


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(White.isChecked()){
                    stringBuffer.append("White,");
                    flag=true;
                }
                if(Yellow.isChecked()){
                    stringBuffer.append("Yellow,");
                    flag=true;
                }
                if(Orange.isChecked()){
                    stringBuffer.append("Orange,");
                    flag=true;
                }
                if(Green.isChecked()){
                    stringBuffer.append("Green,");
                    flag=true;
                }

                if(flag){ //if user selects then store the content and move to next page
                    sharedPreferences.edit().putString("NationalFlag",stringBuffer.toString()).commit();
                    Intent i = new Intent(SecondGame2.this, SummaryActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        });

    }
}
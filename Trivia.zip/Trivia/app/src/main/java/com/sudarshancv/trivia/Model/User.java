package com.sudarshancv.trivia.Model;

public class User {
    String name;
    String Cricketer;
    String NationalFlag;
    String Timestamp;

    public User(){};

    public User(String name, String Cricketer, String NationalFlag,String Timestamp){
        this.name = name;
        this.Cricketer = Cricketer;
        this.NationalFlag = NationalFlag;
        this.Timestamp = Timestamp;
    }
    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getCricketer(){
        return this.Cricketer;
    }

    public void setCricketer(String Cricketer){
        this.Cricketer = Cricketer;
    }

    public String getNationalFlag(){
        return this.NationalFlag;
    }

    public void setNationalFlag(String NationalFlag){
        this.NationalFlag = NationalFlag;
    }

    public String getTimestamp(){
        return this.Timestamp;
    }

    public void setTimestamp(String Timestamp){
        this.Timestamp = Timestamp;
    }

}

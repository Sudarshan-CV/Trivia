package com.sudarshancv.trivia.Utility;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.sudarshancv.trivia.Model.User;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DbHandler extends SQLiteOpenHelper {
    private static final int DATABASE_Version = 1;
    private static final String DATABASE_NAME = "UserSmartness";
    private static final String TABLE_NAME = "User";
    private static final String ID = "id";
    private static final String UserName= "UserName";
    private static final String Cricketer= "Cricketer";
    private static final String FlagColour= "FlagColour";
    private static final String TimeStamp= "TimeStamp";
    //table creation
    private static final String CREATE_TABLE = "CREATE TABLE "+TABLE_NAME+
            " ("+ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+UserName+" VARCHAR(255) ,"+
            Cricketer+" VARCHAR(225) ,"+ FlagColour+" VARCHAR(225),"+TimeStamp+" VARCHAR(225));";

    private static final String DROP_TABLE ="DROP TABLE IF EXISTS "+TABLE_NAME;
    private Context context;

    public DbHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_Version);
        this.context=context;
    }

    //db creation
    public void onCreate(SQLiteDatabase db) {

        try {
            db.execSQL(CREATE_TABLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // Drop older table if exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // Create tables again
        onCreate(db);
    }

    //insert data to the table
    public long insertData(String userName, String cricketer,String flagColour)
    {
        String color =flagColour.substring(0,flagColour.length()-1);
        color= color.replace(",","_");
        String name =userName.replace(",","_");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
        String currentDateandTime = sdf.format(new Date());
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(UserName, name);
        contentValues.put(Cricketer, cricketer);
        contentValues.put(FlagColour, color);
        contentValues.put(TimeStamp, currentDateandTime);

        long id = db.insert(TABLE_NAME, null , contentValues);
        return id;
    }

    //get all data from table
    public List<User> getAllDetails() {
        List<User> userDetails = new ArrayList<User>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setName(cursor.getString(1));
                user.setCricketer(cursor.getString(2));
                user.setNationalFlag(cursor.getString(3));
                user.setTimestamp(cursor.getString(4));
                // Adding userDetails to list
                userDetails.add(user);
            } while (cursor.moveToNext());
        }

        // return User list
        return userDetails;
    }

}

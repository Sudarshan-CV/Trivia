package com.sudarshancv.trivia.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.sudarshancv.trivia.R;

public class FirstGame1 extends AppCompatActivity {
    Button button;
    RadioButton cricketerRadioButton;
    RadioGroup radioGroup;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_game1);
        //mapping objects
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
        button =(Button) findViewById(R.id.nextFirstGame);
        sharedPreferences = getSharedPreferences("trivia",0);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                cricketerRadioButton = (RadioButton) findViewById(selectedId);
                if(selectedId==-1){ //check is radio button is selected or not
                    Toast.makeText(FirstGame1.this,"Nothing selected", Toast.LENGTH_SHORT).show();
                }
                else{
                    sharedPreferences.edit().putString("cricketer",cricketerRadioButton.getText().toString()).commit();
                    Toast.makeText(FirstGame1.this,cricketerRadioButton.getText(), Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(FirstGame1.this, SecondGame2.class);
                    startActivity(i);
                    finish();
                }
            }
        });
    }
}
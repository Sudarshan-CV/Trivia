package com.sudarshancv.trivia.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.sudarshancv.trivia.R;
import com.sudarshancv.trivia.Model.User;
import com.sudarshancv.trivia.Utility.DbHandler;

import java.util.List;

public class SummaryActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    TextView text2name,text5,text7;
    Button finish,history;
    String name,cricketer,NationalFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);
        finish =(Button) findViewById(R.id.nextFinish);
        history =(Button) findViewById(R.id.nextHistory);
        text2name =(TextView) findViewById(R.id.text2name);
        text5 =(TextView) findViewById(R.id.text5);
        text7 =(TextView) findViewById(R.id.text7);
        NationalFlag="";name="";cricketer="";

        // get data from sharedPreferences
        sharedPreferences = getSharedPreferences("trivia",0);
        if(sharedPreferences.contains("name") ){
            name= sharedPreferences.getString("name","");
        }
        if(sharedPreferences.contains("cricketer") ){
            cricketer= sharedPreferences.getString("cricketer","");
        }
        if(sharedPreferences.contains("NationalFlag") ){
            NationalFlag= sharedPreferences.getString("NationalFlag","");
        }

        //set data
        text2name.setText("Hello “"+name +"” ,");

        text5.setText("Answer:“"+cricketer +"”");

        text7.setText("Answer: “ "+NationalFlag +"“");

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DbHandler db = new DbHandler(getApplicationContext());

                // Inserting User
                Log.d("Insert: ", "Inserting ..");
               long id= db.insertData(name, cricketer,NationalFlag);
               if(id <=0 ){
                   Log.d("Insert: ", "Failed");
               }else {
                   Log.d("Insert: ", "Success");
                   Intent i = new Intent(SummaryActivity.this, MainActivity.class);
                   startActivity(i);
                   finish();
               }


            }
        });

        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DbHandler db = new DbHandler(getApplicationContext());
                StringBuffer history = new StringBuffer();
                List<User> UserData = db.getAllDetails();
                int count=1;
                for (User us : UserData) {
                    StringBuffer text = new StringBuffer();
                    text.append("GAME "+count+":"+us.getTimestamp());
                    text.append("\n\n");
                    text.append("Name :"+us.getName());
                    text.append("\n");
                    text.append("Who is the best cricketer in the world?");
                    text.append("\n");
                    text.append("Answer :"+us.getCricketer() );
                    text.append("\n\n");
                    text.append("What are the colours in the national flag?");
                    text.append("\n");
                    text.append("Answer :"+us.getNationalFlag().replace("_",",") );
                    text.append("\n\n");
                    history.append(text);
                    count++;
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(SummaryActivity.this);
                builder.setCancelable(true);
                builder.setTitle("History");
                builder.setMessage(history);
                builder.show();

            }
        });
    }
}